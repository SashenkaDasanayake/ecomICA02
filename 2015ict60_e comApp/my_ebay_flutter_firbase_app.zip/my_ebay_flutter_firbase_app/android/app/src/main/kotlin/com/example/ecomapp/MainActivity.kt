package com.example.ecomapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
